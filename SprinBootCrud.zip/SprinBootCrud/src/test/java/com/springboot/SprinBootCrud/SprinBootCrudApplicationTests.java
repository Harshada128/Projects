package com.springboot.SprinBootCrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprinBootCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
