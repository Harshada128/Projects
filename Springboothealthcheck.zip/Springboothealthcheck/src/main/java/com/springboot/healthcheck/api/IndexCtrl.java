package com.springboot.healthcheck.api;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/api")
public class IndexCtrl {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(IndexCtrl.class);

	// Sample endpoint to check that the project is successfully started or not.
    // Url - http://localhost:10095/api/welcome
    @GetMapping(value = "/welcome")
    public ResponseEntity<String> welcome() {
    	LOGGER.info("Returning the welcome response.");
        return new ResponseEntity<>("Hello world", HttpStatus.OK);
    }
}
